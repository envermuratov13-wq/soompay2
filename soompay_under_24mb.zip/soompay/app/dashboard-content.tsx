
"use client";

import { useState } from "react";

type Transaction = {
  id: string;
  customer: string;
  date: string;
  amount: number;
  status: "Успешно" | "Ожидание" | "Отклонено";
};


export default function Home() {
  const [number, setNumber] = useState("");
  const [amount, setAmount] = useState("100");

  const [transactions, setTransactions] = useState<Transaction[]>([
    { id: "Евгений Гринкевич", customer: "+79900266782", date: "13 ноя, 10:42", amount: 250, status: "Успешно" },
    { id: "Дмитрий Иванов", customer: "+79900855619", date: "13 ноя, 09:18", amount: 120, status: "Ожидание" },
    { id: "Энвер Муратов", customer: "+79900177152", date: "12 ноя, 18:35", amount: 480, status: "Успешно" },
    { id: "Алексей Петров", customer: "+79900222782", date: "12 ноя, 16:20", amount: 75, status: "Отклонено" },
  ]);


  const [showModal, setShowModal] = useState(false);


  function createPayment(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    const value = Number(amount);
    if (!number || !Number.isFinite(value) || value <= 0) return;

    const newTransaction: Transaction = {
      id: `SP-${Date.now().toString().slice(-5)}`,
      customer: number,
      date: new Date().toLocaleString("ru-RU", {
        day: "2-digit",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
      }),
      amount: value,
      status: "Ожидание",
    };

    setTransactions((current) => [newTransaction, ...current]);
    setShowModal(false);
  }

  const total = transactions.reduce((sum, item) => sum + item.amount, 0);

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">S</div>
          <span>soom<span className="brand-light">pay</span></span>
        </div>

        <div className="side-label">ПЛАТФОРМА</div>
        <nav className="navigation">
          <a className="nav-item active" href="#">▦ <span>Обзор</span></a>
          <a className="nav-item" href="#transactions">⇄ <span>Транзакции</span></a>
          <a className="nav-item" href="#balance">◈ <span>Баланс</span></a>
          <a className="nav-item" href="#analytics">▥ <span>Аналитика</span></a>
        </nav>

        <div className="side-label settings-label">СИСТЕМА</div>
        <a className="nav-item" href="#settings">⚙ <span>Настройки</span></a>

        <div className="sidebar-bottom">
          <div className="admin-avatar">AD</div>
          <div>
            <strong>Administrator</strong>
            <small>Администратор</small>
          </div>
          <span className="online-dot" />
        </div>
      </aside>

      <section className="main-content">
        <header className="topbar">
          <div>
            <div className="breadcrumb">Платформа / Обзор</div>
            <h1>Обзор</h1>
          </div>
          <div className="top-actions">
            <span className="demo-badge">● ENVIRONMENT</span>
            <div className="top-avatar">AD</div>
          </div>
        </header>

        <div className="welcome-row">
          <div>
            <h2>Добро пожаловать в SoomPay</h2>
            <p>Вот что происходит с вашей платформой сегодня.</p>
          </div>
          <button className="primary-button" onClick={() => setShowModal(true)}>
            + Создать платёж
          </button>
        </div>

        <div className="stats-grid">
          <article className="stat-card" id="balance">
            <div className="stat-heading"><span>Мой-баланс</span><span>◈</span></div>
            <div className="stat-value">€12,450.00</div>
            <div className="stat-note positive">↑ 12.8% <span>условный рост</span></div>
          </article>

          <article className="stat-card">
            <div className="stat-heading"><span>Мой оборот</span><span>↗</span></div>
            <div className="stat-value">€{total.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
            <div className="stat-note positive">↑ 8.2% <span>мои-данные</span></div>
          </article>

          <article className="stat-card">
            <div className="stat-heading"><span>Транзакции</span><span>⇄</span></div>
            <div className="stat-value">{transactions.length.toString().padStart(2, "0")}</div>
            <div className="stat-note">Все  операции</div>
          </article>

          <article className="stat-card">
            <div className="stat-heading"><span>Успешные платежи</span><span>✓</span></div>
            <div className="stat-value">{transactions.filter(t => t.status === "Успешно").length}</div>
            <div className="stat-note positive">Обработка</div>
          </article>
        </div>

        <div className="content-grid">
          <article className="panel analytics-panel" id="analytics">
            <div className="panel-heading">
              <div><h3>Аналитика</h3><p>Объём операций</p></div>
              <span className="period-label">Последние 7 дней⌄</span>
            </div>
            <div className="chart">
              {[35, 55, 42, 78, 58, 90, 68, 100, 73, 85, 60, 95].map((height, i) => (
                <div className="chart-column" key={i}>
                  <div className="chart-bar" style={{ height: `${height}%` }} />
                </div>
              ))}
            </div>
            <div className="chart-labels">
              <span>Пн</span><span>Вт</span><span>Ср</span><span>Чт</span><span>Пт</span><span>Сб</span><span>Вс</span>
            </div>
          </article>

          <article className="panel balance-panel">
            <div className="panel-heading">
              <div><h3>Баланс</h3><p> Счёт</p></div>
              <span className="balance-icon">€</span>
            </div>
            <div className="balance-number">€12,450.00</div>
            <div className="balance-caption">Мои средства</div>
            <div className="balance-divider" />
            <div className="balance-line"><span>Доступный баланс</span><strong>€12,450.00</strong></div>
            <div className="balance-line"><span>Реальные средства</span><strong>€0.00</strong></div>
          </article>
        </div>

        <article className="panel transactions-panel" id="transactions">
          <div className="panel-heading">
            <div><h3>Последние транзакции</h3><p>История операций</p></div>
            <button className="secondary-button" onClick={() => setShowModal(true)}>+ Создать платёж</button>
          </div>

          <div className="table-wrap">
            <table>
              <thead><tr><th>ID операции</th><th>Клиент</th><th>Дата</th><th>Сумма</th><th>Статус</th></tr></thead>
              <tbody>
                {transactions.map((item) => (
                  <tr key={item.id}>
                    <td className="transaction-id">{item.id}</td>
                    <td>{item.customer}</td>
                    <td>{item.date}</td>
                    <td className="amount-cell">€{item.amount.toFixed(2)}</td>
                    <td><span className={`status status-${item.status === "Успешно" ? "success" : item.status === "Ожидание" ? "pending" : "failed"}`}>{item.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </article>

        <footer className="footer">
          <span>© 2026 SoomPay · Admin Dashboard</span>
          <span className="footer-warning"> — платежи </span>
        </footer>
      </section>

      {showModal && (
        <div className="modal-backdrop" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setShowModal(false)}>×</button>
            <h2>Создать платёж</h2>
            <p>Операция будет добавлена историю.</p>
            <form onSubmit={createPayment}>
              <label>Номер клиента</label>
              <input type="number" placeholder="+79900123123" value={number} onChange={(e) => setNumber(e.target.value)} required />
              <label>Сумма (RUB)</label>
              <input type="number" min="0.01" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} required />
              <button className="primary-button modal-submit" type="submit">Создать платёж</button>
            </form>
            <div className="modal-disclaimer">Процесинговая платформа</div>
          </div>
        </div>
      )}
    </main>
  );
}
