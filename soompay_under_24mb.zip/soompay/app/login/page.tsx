
"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const supabase = createClient();

      const { error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (error) {
        setError("Неверный логин или пароль.");
        return;
      }

      router.replace("/");
      router.refresh();
    } catch {
      setError("Ошибка подключения. Попробуй ещё раз.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{
      minHeight: "100vh",
      display: "grid",
      placeItems: "center",
      background: "#090d12",
      color: "#ffffff",
      padding: "24px"
    }}>
      <form onSubmit={handleSubmit} style={{
        width: "100%",
        maxWidth: "400px",
        padding: "32px",
        background: "#141b24",
        border: "1px solid #263241",
        borderRadius: "16px"
      }}>
        <h1 style={{ fontSize: "28px", marginBottom: "8px" }}>
          SoomPay
        </h1>

        <p style={{ color: "#9aa7b7", marginBottom: "28px" }}>
          Вход в личный кабинет
        </p>

        <label>Email (логин)</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={inputStyle}
          placeholder="name@example.com"
        />

        <label>Пароль</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={inputStyle}
          placeholder="Введите пароль"
        />

        {error && (
          <p style={{ color: "#ff7777", marginTop: "12px" }}>
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={loading}
          style={{
            width: "100%",
            marginTop: "22px",
            padding: "13px",
            border: "none",
            borderRadius: "8px",
            background: "#3478f6",
            color: "#fff",
            cursor: "pointer"
          }}
        >
          {loading ? "Вход..." : "Войти"}
        </button>
      </form>
    </main>
  );
}

const inputStyle = {
  display: "block",
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  marginBottom: "20px",
  borderRadius: "8px",
  border: "1px solid #354355",
  background: "#0c121a",
  color: "#ffffff"
};
